# Nexora Technologies – HR Workforce Analytics Dataset

This folder contains **synthetic practice data** for a Snowflake SQL HR analytics portfolio project. It does not contain real employee information.

## CSV files
- EMPLOYEES.csv – 150 employee records
- DEPARTMENTS.csv – 8 departments
- JOBS.csv – 12 job roles and salary ranges
- LOCATIONS.csv – 8 office locations
- COUNTRIES.csv – 6 countries
- REGIONS.csv – 4 regions
- JOB_HISTORY.csv – 30 previous job assignments

## Main relationships
- EMPLOYEES.DEPARTMENT_ID → DEPARTMENTS.DEPARTMENT_ID
- EMPLOYEES.JOB_ID → JOBS.JOB_ID
- EMPLOYEES.MANAGER_ID → EMPLOYEES.EMPLOYEE_ID
- DEPARTMENTS.LOCATION_ID → LOCATIONS.LOCATION_ID
- LOCATIONS.COUNTRY_ID → COUNTRIES.COUNTRY_ID
- COUNTRIES.REGION_ID → REGIONS.REGION_ID
- JOB_HISTORY.EMPLOYEE_ID → EMPLOYEES.EMPLOYEE_ID
- JOB_HISTORY.JOB_ID → JOBS.JOB_ID
- JOB_HISTORY.DEPARTMENT_ID → DEPARTMENTS.DEPARTMENT_ID

## Snowflake import
1. Create a database and schema for the project.
2. In Snowsight, open **Data > Add Data > Load files into a Table**.
3. Upload each CSV and load it into a table with the matching name.
4. Check that column types are appropriate (IDs as NUMBER, salary as NUMBER, dates as DATE, text as VARCHAR).

All records are fictional and intended for SQL practice and portfolio demonstration.
